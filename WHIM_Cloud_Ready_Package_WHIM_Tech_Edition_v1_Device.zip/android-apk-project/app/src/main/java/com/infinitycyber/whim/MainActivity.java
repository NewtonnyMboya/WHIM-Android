package com.infinitycyber.whim;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.ValueCallback;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.net.http.SslError;
import android.webkit.SslErrorHandler;
import android.content.ActivityNotFoundException;
import android.util.Log;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.PermissionRequest;
import android.os.Build;

public class MainActivity extends Activity {
  private WebView webView;
  private ValueCallback<Uri[]> fileCallback;
  private PermissionRequest pendingCameraRequest;
  private static final int FILE_PICKER = 721;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    webView = new WebView(this);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    s.setDatabaseEnabled(true);
    s.setCacheMode(WebSettings.LOAD_DEFAULT);
    webView.setSaveEnabled(true);
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        return routeExternalUrl(url);
      }
      @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
        return routeExternalUrl(request.getUrl().toString());
      }
      private boolean routeExternalUrl(String url) {
        try {
          Uri uri = Uri.parse(url);
          String scheme = uri.getScheme();
          if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            return true;
          }
          return scheme != null && !"file".equalsIgnoreCase(scheme) && !"about".equalsIgnoreCase(scheme);
        } catch (ActivityNotFoundException e) {
          return true;
        } catch (Exception e) {
          Log.w("WHIM", "Blocked URL navigation", e);
          return true;
        }
      }
    });
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public void onPermissionRequest(final PermissionRequest request) {
        runOnUiThread(() -> {
          boolean asksForCamera = false;
          for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) asksForCamera = true;
          }
          if (!asksForCamera) { request.deny(); return; }
          if (Build.VERSION.SDK_INT < 23 ||
              checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
          } else {
            if (pendingCameraRequest != null) pendingCameraRequest.deny();
            pendingCameraRequest = request;
            requestCameraPermission();
          }
        });
      }
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = callback;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
        try { startActivityForResult(i, FILE_PICKER); return true; }
        catch (Exception e) { fileCallback = null; return false; }
      }
    });
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
  }
  private static final int CAMERA_PERMISSION = 722;
  private void requestCameraPermission() {
    if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION);
    }
  }
  private void showCameraPermissionHelp() {
    new AlertDialog.Builder(this)
      .setTitle("Camera access is disabled")
      .setMessage("Material scanning needs camera permission. You can try again or open this app's Android settings and allow Camera. WHIM cannot override system privacy controls or another app's camera use.")
      .setNegativeButton("Cancel", null)
      .setNeutralButton("Try again", (dialog, which) -> requestCameraPermission())
      .setPositiveButton("Open app settings", (dialog, which) -> {
        Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
          Uri.parse("package:" + getPackageName()));
        try { startActivity(intent); }
        catch (ActivityNotFoundException e) { Log.w("WHIM", "Unable to open app settings", e); }
      }).show();
  }
  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == CAMERA_PERMISSION) {
      boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
      if (pendingCameraRequest != null) {
        PermissionRequest request = pendingCameraRequest;
        pendingCameraRequest = null;
        if (granted) request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        else request.deny();
      }
      if (!granted) showCameraPermissionHelp();
    }
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == FILE_PICKER && fileCallback != null) {
      Uri[] results = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
      fileCallback.onReceiveValue(results); fileCallback = null;
    }
  }
  @Override protected void onPause() {
    if (webView != null) webView.onPause();
    super.onPause();
  }
  @Override protected void onResume() {
    super.onResume();
    if (webView != null) webView.onResume();
  }
  @Override protected void onDestroy() {
    if (pendingCameraRequest != null) {
      pendingCameraRequest.deny();
      pendingCameraRequest = null;
    }
    if (webView != null) {
      webView.stopLoading();
      webView.destroy();
      webView = null;
    }
    super.onDestroy();
  }
  @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
