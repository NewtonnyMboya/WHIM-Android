from pathlib import Path
import json,base64,os,zipfile,hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
root=Path('/tmp/whimlatest')
keydoc=json.loads(Path('/mnt/data/files/WHIM_Owner_Unlock_Key(3).json').read_text())
key=base64.b64decode(keydoc['key']); owner=keydoc['owner']; nonce=os.urandom(12)
plain=(root/'app.html').read_bytes()
cipher=AESGCM(key).encrypt(nonce,plain,('WHIM-OWNER-SOURCE-v1|'+owner).encode())
payload={'format':'WHIM-AESGCM-v1','owner':owner,'nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(cipher).decode()}
encoded=json.dumps(payload,separators=(',',':')).encode()
for rel in ['winapp/source.enc','android-apk-project/app/src/main/assets/source.enc']:
 (root/rel).write_bytes(encoded)
notes='''WHIM HUB REORGANIZATION UPDATE

The Home button now opens WHIM Hub, which is also the default landing view. The hub uses a centered circular WHIM mark and the WHIM Hub title. Its icon-led menu opens the existing Dashboard, Material Information Sheet, In-Out Warehouse Flow, Backup/Data, scanner, company identity, appearance/import, backup export, movement-summary email, and Help workflows.

Data integrity: no parallel inventory data model or duplicate store was introduced. Existing workflows continue to use the existing shared state, normalization, validation, and local persistence key. The hub's actions invoke existing workflow functions and views. Material and warehouse movement editors retain the existing validation/save-before-navigation behavior. Existing licensing/authentication, scanner/OCR, item-code matching, backup/import/export, owner-resolution preview, and Gmail report handoff remain in the package.

Performance/quality: responsive hub layout, CSS/SVG round WHIM mark (no extra image dependency), reduced-motion-aware tile animation, and existing active-view rendering are retained. The round mark is inline SVG; Windows and Android encrypted source payloads are regenerated from the same HTML bytes.

Validation performed: ZIP integrity, HTML parser, inline JavaScript syntax, duplicate-ID scan, and AES-GCM decrypt/synchrony checks. Full interactive browser/device QA, measured load-time benchmarks, and Android Gradle APK compilation were not performed in this environment.
'''
(root/'WHIM_HUB_REORGANIZATION_UPDATE.txt').write_text(notes)
for rel in ['winapp/README.txt','PLATFORM_README.txt','android-apk-project/VERIFICATION_STATUS.txt']:
 p=root/rel
 if p.exists():
  p.write_text(p.read_text().rstrip()+'\n\n'+notes)
out=Path('/mnt/data/Warehouse_Inventory_Manager_WHIM_Hub_Integrated_Workflows_Update.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file(): z.write(f,f.relative_to(root).as_posix())
# verification
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert z.read('winapp/source.enc')==z.read('android-apk-project/app/src/main/assets/source.enc')
 obj=json.loads(z.read('winapp/source.enc'))
 recovered=AESGCM(key).decrypt(base64.b64decode(obj['nonce']),base64.b64decode(obj['ciphertext']),('WHIM-OWNER-SOURCE-v1|'+owner).encode())
 assert recovered==plain
print('output',out,'bytes',out.stat().st_size)
print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
print('source bytes',len(plain),'encrypted payloads synchronized and decrypt successfully')
