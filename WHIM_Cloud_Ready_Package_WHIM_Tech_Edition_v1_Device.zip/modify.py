from pathlib import Path
import re,json,base64,os
root=Path('/tmp/whimnext')
p=root/'app.html'; h=p.read_text()
# Move flow Save/Close + Cancel directly under the In-Out Warehouse Flow heading.
flow_start=h.index('<section id="flow"')
flow_end=h.index('</section>',flow_start)
flow=h[flow_start:flow_end]
actions='<div class="workflow-actions" role="group" aria-label="In-Out Warehouse Flow actions"><button type="button" class="btn" onclick="saveAndCloseWorkflow(\'flow\')">Save and Close（保存并关闭）</button><button type="button" class="btn secondary" onclick="cancelWorkflow(\'flow\')">Cancel（取消）</button></div>'
if flow.count(actions)!=1: raise SystemExit('flow actions not found uniquely')
flow=flow.replace(actions,'',1)
needle='<h2>In-Out Warehouse Flow — reference/update ledger</h2>'
if flow.count(needle)!=1: raise SystemExit('flow heading not found uniquely')
flow=flow.replace(needle,needle+'\n    '+actions,1)
h=h[:flow_start]+flow+h[flow_end:]
# Explicit close flag: selecting a workflow tile never toggles/closes it; only Save and Close / Cancel may close it.
h=h.replace("const closed=activateView(viewName);", "const closed=activateView(viewName,true);", 2)
h=h.replace('function activateView(viewName){','function activateView(viewName,closeActiveWorkflow=false){',1)
h=h.replace("const closingWorkflow=persistent.has(viewName)&&activeViews.includes(viewName);", "const closingWorkflow=closeActiveWorkflow&&persistent.has(viewName)&&activeViews.includes(viewName);",1)
# WHIM Home becomes an idempotent opener, not a toggle that sends users back to the last workflow.
start=h.index('function openWhimHub(){')
end=h.index('\nfunction toggleHeading(){',start)
new_func='''function openWhimHub(){
  const heading=document.getElementById('appHeading');
  const button=document.getElementById('headingToggle');
  const current=[...document.querySelectorAll('.view.active')].map(v=>v.id).find(v=>v!=='settings'&&['dashboard','materials','flow'].includes(v));
  if(current)lastNonHubView=current;
  if(!document.getElementById('settings')?.classList.contains('active')){
    if(!activateView('settings'))return;
  }
  // WHIM Home only opens the home view. The WHIM Hub child menu owns its own
  // expand/collapse action; repeated Home clicks do not close the home view.
  const hub=document.getElementById('whimHubPanel');
  const company=document.getElementById('companyIdentityPanel');
  const hubButton=document.querySelector('.whim-home-menu[aria-controls="whimHubPanel"]');
  const companyButton=document.querySelector('.whim-home-menu[aria-controls="companyIdentityPanel"]');
  if(hub)hub.hidden=false;
  if(company)company.hidden=true;
  if(hubButton){hubButton.classList.add('active');hubButton.setAttribute('aria-expanded','true');}
  if(companyButton){companyButton.classList.remove('active');companyButton.setAttribute('aria-expanded','false');}
  if(heading){heading.classList.add('hub-open');heading.classList.add('collapsed');}
  if(button){button.setAttribute('aria-expanded','true');button.setAttribute('aria-label','Open WHIM Home');}
  try{localStorage.setItem('whim_last_open_view_v1','settings');localStorage.setItem('whim_heading_collapsed_v1','1')}catch(e){}
}'''
h=h[:start]+new_func+h[end:]
# Update the explanatory comments to reflect the new control ownership.
h=h.replace('// Keep the Material Information Sheet and In-Out Warehouse Flow as independently\n // collapsible workflows in their existing locations, with clear button state feedback.','// Workflow tiles inside WHIM Hub open workflows. Repeated tile clicks do not close them;\n // Save and Close or Cancel performs the explicit close action.')
p.write_text(h)
# Rebuild inline JS files exactly from inline script blocks (external script tags yield empty bodies).
scripts=re.findall(r'<script\b[^>]*>(.*?)</script>',h,re.S|re.I)
joined='\n'.join(scripts)
(root/'all_inline.js').write_text(joined)
(root/'verify_inline.js').write_text(joined)
# Notes
note='''WHIM HUB-ONLY WORKFLOW ACTION UPDATE

- In-Out Warehouse Flow's Save and Close and Cancel buttons are placed immediately below the “In-Out Warehouse Flow — reference/update ledger” heading.
- Workflow tiles inside WHIM Hub open Material Information Sheet and In-Out Warehouse Flow. Repeated clicks on an already-open workflow tile no longer close the workflow; the explicit Save and Close or Cancel button closes it and returns to WHIM Hub.
- WHIM Home opens the home view and does not toggle back to the previous workflow on repeated clicks. The WHIM Hub child menu controls its own expand/collapse behavior.
- Shared inventory state and existing workflow data paths are preserved.

Validation scope: static source, JavaScript syntax, encrypted asset consistency, and ZIP integrity. No physical-device interaction tests or APK compilation are claimed.
'''
(root/'WHIM_HUB_ONLY_WORKFLOW_ACTION_UPDATE.txt').write_text(note)
for rel in ['PLATFORM_README.txt','android-apk-project/VERIFICATION_STATUS.txt','winapp/README.txt']:
 q=root/rel
 if q.exists(): q.write_text(q.read_text().rstrip()+'\n\n'+note)
# Encrypt updated HTML using owner key and the existing AES-256-GCM/AAD contract.
keydoc=json.load(open('/mnt/data/files/WHIM_Owner_Unlock_Key(3).json'))
key=base64.b64decode(keydoc['key'])
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
nonce=os.urandom(12)
aad=b'WHIM-OWNER-SOURCE-v1|mboyanewtonny@gmail.com'
cipher=AESGCM(key).encrypt(nonce,h.encode(),aad)
payload={'format':'WHIM-AESGCM-v1','owner':'mboyanewtonny@gmail.com','nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(cipher).decode()}
enc=json.dumps(payload,separators=(',',':'))
(root/'winapp/source.enc').write_text(enc)
(root/'android-apk-project/app/src/main/assets/source.enc').write_text(enc)
print('updated',len(h),'js',len(joined),'encrypted',len(enc))
