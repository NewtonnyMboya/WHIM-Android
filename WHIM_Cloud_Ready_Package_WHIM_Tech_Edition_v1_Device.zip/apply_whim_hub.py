from pathlib import Path
p=Path('/tmp/whimlatest/app.html')
s=p.read_text()
# Hub branding styles
needle='/* Integrated Settings Hub: responsive, task-oriented shortcut cards. */'
insert='''/* WHIM Hub home identity and native workflow navigation. */
.whim-hub-brand{display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;padding:18px 10px 10px;margin-bottom:8px}
.whim-hub-mark{width:104px;height:104px;display:block;filter:drop-shadow(0 5px 12px #1d4ed822)}
.whim-hub-brand h2{font-size:23px!important;letter-spacing:.02em;margin:0!important}
.whim-hub-brand p{margin:0;color:var(--muted);max-width:760px}
.settings-shortcuts{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,220px),1fr));gap:10px;margin:14px 0}
.settings-tile{display:flex;align-items:center;text-align:left;gap:12px;min-height:76px;padding:12px;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:12px;transition:transform .15s ease,border-color .15s ease,box-shadow .15s ease}
.settings-tile:hover{transform:translateY(-1px);border-color:var(--accent);box-shadow:0 4px 14px #0f172a10}
.settings-tile .settings-icon{display:grid;place-items:center;flex:0 0 42px;width:42px;height:42px;border-radius:12px;background:color-mix(in srgb,var(--accent) 12%,transparent);font-size:22px}
.settings-tile strong,.settings-tile small{display:block}.settings-tile small{font-weight:400;color:var(--muted);margin-top:3px}
@media(prefers-reduced-motion:reduce){.settings-tile{transition:none}.settings-tile:hover{transform:none}}
'''
s=s.replace(needle,insert)
# Home button always opens actual hub, not dropdown
s=s.replace('onclick="toggleHeading()">⌂ Home（主页）</button>', 'onclick="openWhimHub()">⌂ Home（主页）</button>')
# Rename home dropdown brand description and nav labels
s=s.replace('Material Information Sheet（物料信息表） → In-Out Warehouse Flow（仓库出入库流程） → Live Dashboard（实时仪表板）','WHIM Hub — one entry point to the existing warehouse workflows（WHIM 工作中心 — 进入现有仓库工作流程）')
s=s.replace('<button data-view="dashboard" class="active">Dashboard（仪表板）</button>','<button data-view="settings">WHIM Hub（WHIM 工作中心）</button>\n          <button data-view="dashboard">Dashboard（仪表板）</button>')
s=s.replace('<button data-view="settings">Backup / Data（备份 / 数据）</button>','<button data-view="settings">WHIM Hub / Backup & Data（WHIM 工作中心 / 备份与数据）</button>')
# Default home view branding and menu content
old='''  <div class="panel settings-hub">
    <h2>⚙ Settings Hub（设置中心）</h2>
    <p class="muted">Quick access to the tools used to manage your warehouse, materials, backups, and application appearance.</p>
    <div class="settings-shortcuts" role="group" aria-label="Warehouse Inventory Manager settings shortcuts">'''
new='''  <div class="panel settings-hub">
    <div class="whim-hub-brand" aria-label="WHIM Hub home">
      <svg class="whim-hub-mark" viewBox="0 0 120 120" role="img" aria-label="WHIM round logo">
        <defs><linearGradient id="whimHubGradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2563eb"/><stop offset="1" stop-color="#0f766e"/></linearGradient></defs>
        <circle cx="60" cy="60" r="56" fill="url(#whimHubGradient)"/>
        <circle cx="60" cy="60" r="48" fill="none" stroke="#ffffff" stroke-opacity=".82" stroke-width="2"/>
        <text x="60" y="68" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="26" font-weight="800" letter-spacing="1" fill="#ffffff">WHIM</text>
      </svg>
      <h2>WHIM Hub</h2>
      <p>Warehouse Inventory Manager · Central workspace for the existing inventory workflows</p>
    </div>
    <p class="muted">Choose a workflow to open its live working screen. All workflows read and write the same inventory state; this hub does not create a second copy of inventory data.</p>
    <div class="settings-shortcuts" role="group" aria-label="WHIM Hub native workflow menu">'''
if old not in s: raise SystemExit('hub intro not found')
s=s.replace(old,new)
# replace tiles block entirely
start=s.index('    <div class="settings-shortcuts" role="group" aria-label="WHIM Hub native workflow menu">')
end=s.index('    <p id="settingsHubStatus"',start)
newtiles='''    <div class="settings-shortcuts" role="group" aria-label="WHIM Hub native workflow menu">
      <button type="button" class="settings-tile" onclick="activateView('dashboard')"><span class="settings-icon" aria-hidden="true">📈</span><span><strong>Dashboard</strong><small>Live stock totals, charts and material balances</small></span></button>
      <button type="button" class="settings-tile" onclick="activateView('materials')"><span class="settings-icon" aria-hidden="true">🧵</span><span><strong>Material Information Sheet</strong><small>Create, edit and manage the live material master</small></span></button>
      <button type="button" class="settings-tile" onclick="activateView('flow')"><span class="settings-icon" aria-hidden="true">🔄</span><span><strong>In-Out Warehouse Flow</strong><small>Record and edit inbound/outbound transactions</small></span></button>
      <button type="button" class="settings-tile" onclick="settingsJump('backupDataPanel')"><span class="settings-icon" aria-hidden="true">🗄️</span><span><strong>Backup / Data</strong><small>Export, restore, manage data and sign out</small></span></button>
      <button type="button" class="settings-tile" onclick="openMaterialScanner()"><span class="settings-icon" aria-hidden="true">🔎</span><span><strong>Multi-Image Material Scanner</strong><small>Run OCR and review each scanned material</small></span></button>
      <button type="button" class="settings-tile" onclick="settingsJump('companyIdentityPanel')"><span class="settings-icon" aria-hidden="true">🏢</span><span><strong>Company Identity</strong><small>Update company name and logo settings</small></span></button>
      <button type="button" class="settings-tile" onclick="openPreferences()"><span class="settings-icon" aria-hidden="true">🎨</span><span><strong>Appearance & Excel Restore</strong><small>Theme, font and workbook import controls</small></span></button>
      <button type="button" class="settings-tile" onclick="exportBackup()"><span class="settings-icon" aria-hidden="true">🛡️</span><span><strong>Export JSON Backup</strong><small>Download a portable copy of current inventory</small></span></button>
      <button type="button" class="settings-tile" onclick="exportBackupXLSX()"><span class="settings-icon" aria-hidden="true">📊</span><span><strong>Export Excel Workbook</strong><small>Export material and movement records</small></span></button>
      <button type="button" class="settings-tile" onclick="openMovementEmailDialog()"><span class="settings-icon" aria-hidden="true">✉️</span><span><strong>Email Movement Summary</strong><small>Choose actual inbound/outbound records</small></span></button>
      <button type="button" class="settings-tile" onclick="showOwnerInfo()"><span class="settings-icon" aria-hidden="true">🆘</span><span><strong>Help & Report a Problem</strong><small>Read resolution guidance and prepare owner report</small></span></button>
      <button type="button" class="settings-tile" onclick="refreshCurrentWorkspace()"><span class="settings-icon" aria-hidden="true">⚡</span><span><strong>Refresh Current Data</strong><small>Refresh visible tables from the shared inventory state</small></span></button>
    </div>
'''
s=s[:start]+newtiles+s[end:]
# Add id for backup data panel
s=s.replace('<h2>Backup / Data（备份 / 数据）</h2>', '<h2 id="backupDataPanel">Backup / Data（备份 / 数据）</h2>')
# Rename status and Settings wording in header controls
s=s.replace('aria-label="Open Settings">⚙ Settings（设置）</button>', 'aria-label="Open appearance and import settings">⚙ Settings（设置）</button>')
# Make hub the Home target and default; preserve saved non-home page if user last opened a workflow.
anchor='function toggleHeading(){'
if anchor not in s: raise SystemExit('toggleHeading not found')
s=s.replace(anchor,'''function openWhimHub(){
  activateView('settings');
  const heading=document.getElementById('appHeading');
  const menu=document.getElementById('homeMenu');
  const button=document.getElementById('headingToggle');
  if(menu)menu.classList.remove('open');
  if(button)button.setAttribute('aria-expanded','false');
  if(heading)heading.classList.add('collapsed');
  try{localStorage.setItem('whim_heading_collapsed_v1','1')}catch(e){}
}
function toggleHeading(){''')
oldinit="try{const savedView=localStorage.getItem('whim_last_open_view_v1');activateView(savedView&&document.getElementById(savedView)?.classList.contains('view')?savedView:'dashboard');}catch(e){activateView('dashboard')}\n// Open the Home menu by default at startup, while restoring the last selected workspace.\ntry{toggleHeading()}catch(e){}"
newinit="try{activateView('settings');}catch(e){activateView('settings')}\n// WHIM Hub is the default landing view. Existing dashboard/material/flow screens remain the live workflows behind the hub menu."
if oldinit not in s: raise SystemExit('init block not found')
s=s.replace(oldinit,newinit)
# Update status wording and any relevant headings
s=s.replace('Current workspace refreshed from the latest in-memory inventory data.','WHIM Hub refreshed from the shared in-memory inventory data.')
s=s.replace('Ready. Inventory data is stored in this browser profile.','Ready. WHIM Hub uses the existing shared inventory data in this browser profile.')
p.write_text(s)
print('patched',len(s))
