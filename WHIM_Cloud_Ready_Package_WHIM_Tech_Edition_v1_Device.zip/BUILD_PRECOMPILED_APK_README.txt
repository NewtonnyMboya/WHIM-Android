WHIM — ANDROID APK BUILD PACKAGE

This package is a Gradle Android project, not a precompiled APK. The current execution environment has Java 21 but does not have Gradle, Android SDK platform/build-tools, adb, or an emulator. Network DNS is unavailable here, so the required SDK/Gradle components cannot be downloaded in this environment. No APK has been produced by this run.

BUILD ON A COMPUTER WITH ANDROID SDK/GRADLE:
1. Install Android Studio or install JDK 17+, Gradle 8.7, and Android SDK Platform 35 / Build-Tools 35.0.0.
2. Set ANDROID_HOME (or ANDROID_SDK_ROOT) to the Android SDK location.
3. Run BUILD_PRECOMPILED_APK.sh from this package root in a shell where Gradle is on PATH.
4. The script runs assembleDebug and copies the output to output/Warehouse_Inventory_Manager-debug.apk.
5. Install and test the debug APK on a real Android device. For production, create a release build signed with your own private release keystore; do not distribute the debug APK as a production release.

PROJECT NOTES:
- Android project: android-apk-project/
- compileSdk: 35; applicationId: com.infinitycyber.whim; minSdk: 23; targetSdk: 28.
- The package contains the logo/icon assets and encrypted source asset.
- Static package checks only; Android runtime behavior has not been verified. Test owner unlock, trial, product-key activation, inventory persistence, backup/restore, monthly line graph, and Skrill browser handoff before release.
- Skrill link opening does not automatically verify payment; product keys are issued manually after payment confirmation according to the project notes.
- Keep owner unlock JSON and signing keystore private. Neither is embedded in the APK project.
