#!/bin/sh
# Opens the bundled HTML app in the system's default browser on macOS/Linux.
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
APP="$SCRIPT_DIR/index.html"
if [ ! -f "$APP" ]; then
  echo "Could not find index.html beside this launcher."
  exit 1
fi
case "$(uname -s 2>/dev/null)" in
  Darwin)
    open "$APP"
    ;;
  *)
    if command -v xdg-open >/dev/null 2>&1; then
      xdg-open "$APP"
    elif command -v gio >/dev/null 2>&1; then
      gio open "$APP"
    else
      echo "No supported desktop opener found. Open index.html in a browser."
      exit 1
    fi
    ;;
esac
