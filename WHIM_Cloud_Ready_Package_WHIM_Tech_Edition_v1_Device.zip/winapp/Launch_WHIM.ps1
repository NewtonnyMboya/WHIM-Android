$App = Join-Path $PSScriptRoot 'index.html'

$Candidates = @(
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:LocalAppData\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LocalAppData\Google\Chrome\Application\chrome.exe"
)

$Browser = $Candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($Browser) {
    Start-Process -FilePath $Browser -ArgumentList @("--app=$App")
} else {
    Start-Process -FilePath $App
    Write-Host "If the app does not display correctly, use a compatible browser for your Windows version."
}
