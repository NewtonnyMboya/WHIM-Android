@echo off
setlocal
cd /d "%~dp0"
set "APP=%~dp0index.html"

REM Launch with an installed Chromium-based browser when available.
REM Windows 8/8.1 may only have older browser versions; see README.txt.
for %%B in (
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
) do (
  if exist %%B (
    start "WHIM" %%B --app="%APP%"
    exit /b 0
  )
)

REM Fall back to the user's default browser.
start "" "%APP%"
echo.
echo If the app does not display correctly, install a compatible browser
echo available for your Windows version, then run this launcher again.
pause
