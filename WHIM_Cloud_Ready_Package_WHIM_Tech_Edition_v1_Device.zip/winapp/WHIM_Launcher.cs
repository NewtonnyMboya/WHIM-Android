using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class WHIMLauncher
{
    [STAThread]
    private static void Main()
    {
        string dir = AppDomain.CurrentDomain.BaseDirectory;
        string app = Path.Combine(dir, "index.html");
        string encrypted = Path.Combine(dir, "source.enc");
        if (!File.Exists(app) || !File.Exists(encrypted))
        {
            MessageBox.Show(
                "WHIM files are missing.\n\nKeep WHIM.exe beside index.html and source.enc, then try again.",
                "Warehouse Inventory Manager",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        string[] candidates = new string[] {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft", "Edge", "Application", "msedge.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft", "Edge", "Application", "msedge.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Microsoft", "Edge", "Application", "msedge.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Google", "Chrome", "Application", "chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Google", "Chrome", "Application", "chrome.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google", "Chrome", "Application", "chrome.exe")
        };

        foreach (string browser in candidates)
        {
            if (File.Exists(browser))
            {
                Process.Start(new ProcessStartInfo {
                    FileName = browser,
                    Arguments = "--app=\"" + app + "\"",
                    UseShellExecute = false
                });
                return;
            }
        }

        Process.Start(new ProcessStartInfo { FileName = app, UseShellExecute = true });
    }
}
