# Build WHIM.exe on Windows using the built-in .NET Framework C# compiler.
# Run this script from the extracted winapp folder in Windows PowerShell.
$ErrorActionPreference = 'Stop'
$src = Join-Path $PSScriptRoot 'WHIM_Launcher.cs'
$out = Join-Path $PSScriptRoot 'WHIM.exe'
if (-not (Test-Path (Join-Path $PSScriptRoot 'index.html')) -or
    -not (Test-Path (Join-Path $PSScriptRoot 'source.enc'))) {
    throw "Required WHIM files are missing. Keep WHIM.exe beside index.html and source.enc."
}
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path $compiler)) {
    throw "The .NET Framework C# compiler was not found. Use a Windows machine with .NET Framework 4.x installed."
}
& $compiler /nologo /target:winexe /optimize+ /out:$out $src
if ($LASTEXITCODE -ne 0) { throw "Compilation failed with exit code $LASTEXITCODE" }
Write-Host "Built: $out"
Write-Host "Keep WHIM.exe, index.html, source.enc, and gst-logo.jpg together."
