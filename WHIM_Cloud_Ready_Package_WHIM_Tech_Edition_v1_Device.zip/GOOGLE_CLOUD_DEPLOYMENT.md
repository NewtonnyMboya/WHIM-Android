# WHIM on Google Cloud Run (single-device storage)

## What this deployment does
- Serves the existing `app.html` as a secure HTTPS web application using Cloud Run and a small Nginx container.
- Keeps WHIM's current inventory, user accounts, session, and license state in the browser's `localStorage`, as requested.
- Does **not** upload inventory data to Google Cloud, sync across devices, or provide server-side account recovery. Data is tied to the same browser profile on the same device and can be lost if browser data is cleared or the device is lost.
- The `cloud-server/` API scaffold is not used by this single-device deployment. Do not configure its shared bearer token in the browser.

## Deploy using Google Cloud Shell
Prerequisites: a Google Cloud project with billing enabled, permission to deploy Cloud Run, and `gcloud` available. No credentials are included in this archive.

1. Upload and extract this ZIP in Google Cloud Shell, then `cd` into the extracted package directory (the directory containing `Dockerfile` and `app.html`).
2. Set your project and region (example region `us-central1`; choose a region appropriate for your users):

```sh
gcloud auth login
gcloud config set project YOUR_PROJECT_ID
gcloud services enable run.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com
gcloud run deploy whim-web \
  --source . \
  --region us-central1 \
  --allow-unauthenticated \
  --port 8080
```

3. When deployment finishes, open the HTTPS service URL printed by `gcloud run deploy`.
4. Verify the URL plus `/health` returns `{"status":"ok","service":"whim-static-web"}`.
5. Test sign-in and inventory actions in the target browser. Use the same device and browser profile consistently.

## Notes and limits
- `--allow-unauthenticated` makes the website public on the internet; it does not expose inventory stored only in a user's browser, but the app's own browser-based sign-in is not server-grade authentication. Do not treat it as suitable for sensitive or regulated data without a security review.
- Cloud Run hosts the application files; it does not make `localStorage` cloud storage. Each browser/device has its own independent data.
- Cloud Run may scale/restart freely because this container has no persistent server-side inventory files.
- No custom domain has been configured. Google provides a service URL after successful deployment.
- Costs may apply for Cloud Run, builds, artifact storage, and network usage. Review current Google Cloud pricing and billing before deploying.
- The API in `cloud-server/` is deliberately not connected for this single-device requirement. If you later want cloud backups or cross-device access, that requires authenticated API integration and a database migration plan.
- Keep `WHIM_Owner_Unlock_Key.json` separate and private. It is not part of this ZIP.
