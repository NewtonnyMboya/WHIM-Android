import json,base64,os,shutil,zipfile
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
root=Path('/tmp/whim')
keydoc=json.load(open('/mnt/data/files/WHIM_Owner_Unlock_Key(3).json'))
key=base64.b64decode(keydoc['key']); owner=keydoc['owner']; nonce=os.urandom(12)
plain=(root/'app.html').read_bytes(); cipher=AESGCM(key).encrypt(nonce,plain,('WHIM-OWNER-SOURCE-v1|'+owner).encode())
payload={'format':'WHIM-AESGCM-v1','owner':owner,'nonce':base64.b64encode(nonce).decode(),'ciphertext':base64.b64encode(cipher).decode()}
encoded=json.dumps(payload,separators=(',',':')).encode()
(root/'winapp/source.enc').write_bytes(encoded);(root/'android-apk-project/app/src/main/assets/source.enc').write_bytes(encoded)
for folder in ['winapp','android-apk-project']:
 p=root/folder/'EMAIL_SUMMARY_UPDATE.txt';p.write_text('WHIM EMAIL SUMMARY UPDATE\n\nAdded an Email Inbound / Outbound Summary workflow to Backup / Data. The sender enters a Gmail address ending in @gmail.com, chooses inbound or outbound, selects individual matching movement records, and generates a matching .xlsx workbook before opening the default email compose handler with a prepared subject and summary. Because browser security does not allow reliable automatic attachment, the sender must attach the downloaded workbook manually. Workbook rows are filtered to selected movements and associated material codes.\n\nValidation: static source inspection performed. Runtime testing in a browser and APK compilation were not performed in this environment.\n')
# update root note
(root/'EMAIL_SUMMARY_UPDATE.txt').write_text('WHIM email summary update: added Gmail recipient validation, inbound/outbound selection, individual transaction selection, XLSX export containing selected records, and mailto compose handoff. Browser restrictions require manual attachment of the downloaded workbook. Runtime browser testing and APK compilation not performed.')
out='/mnt/data/Warehouse_Inventory_Manager_Multi_Image_Scanner_Update.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if f.is_file(): z.write(f, f.relative_to(root).as_posix())
print(out,os.path.getsize(out))
