from pathlib import Path
p=Path('/tmp/whim/app.html')
s=p.read_text()
start=s.index('<div id="materialScannerModal" class="modal">')
end=s.index('\n/* Offline product-key validation.', start)
new=r'''<div id="materialScannerModal" class="modal">
 <div class="modal-card" style="max-width:900px">
  <h2>Multi-Image Material Scanner（多图片物料扫描器）</h2>
  <p class="notice">Select multiple label images. Each image is processed as a separate material. OCR results are suggestions; verify every field before applying or saving.</p>
  <div class="field"><label for="scanImageFiles">Choose material label images（选择多个物料标签图片）</label><input id="scanImageFiles" type="file" accept="image/*" multiple onchange="processMaterialImages(this.files)"></div>
  <div id="scanCameraStatus" class="notice" role="status" aria-live="polite">Choose one or more images to begin OCR identification.</div>
  <div id="scanResults" class="scan-results" aria-live="polite"></div>
  <div class="modal-actions"><button type="button" class="btn secondary" onclick="closeModal('materialScannerModal')">Close（关闭）</button></div>
  <p class="muted">Existing style-and-color combinations automatically use their existing item codes. New combinations require a new item code before they can be applied. OCR requires the Tesseract engine to load; an internet connection may be needed on first use.</p>
 </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<style>
.scan-results{display:grid;gap:12px;margin-top:14px}.scan-result{border:1px solid var(--line);border-radius:10px;padding:12px;background:var(--card)}.scan-result h3{font-size:14px;margin:0 0 10px}.scan-result .modal-grid{gap:10px}.scan-result .field input{width:100%;min-width:0}.scan-result .scan-raw{font-size:12px;color:var(--muted);white-space:pre-wrap;overflow-wrap:anywhere;margin:8px 0}.scan-match{font-size:12px;color:var(--green);margin:6px 0}.scan-new{font-size:12px;color:var(--amber);margin:6px 0}
</style>
<script>
// Multi-image OCR material entry. Each image is kept as a separate reviewable result.
let whimPendingInbound=null, whimScanResults=[];
function openMaterialScanner(){
 const input=document.getElementById('scanImageFiles');if(input)input.value='';
 document.getElementById('scanCameraStatus').textContent='Choose one or more images to begin OCR identification.';
 renderMaterialScanResults();document.getElementById('materialScannerModal').classList.add('open');
}
function normalizeScanValue(v){return String(v||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase()}
function findScannedMaterial(style,color){
 const st=normalizeScanValue(style),co=normalizeScanValue(color);if(!st||!co)return null;
 return (state.materials||[]).find(m=>normalizeScanValue(m.style)===st&&normalizeScanValue(m.color)===co)||null;
}
function hasScannedStyle(style){const st=normalizeScanValue(style);return !!st&&(state.materials||[]).some(m=>normalizeScanValue(m.style)===st)}
function parseMaterialOCR(text){
 const lines=String(text||'').split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
 const afterLabel=(label)=>{const re=new RegExp('(?:^|[^A-Z])'+label+'\\s*[:：#\\-]?\\s*(.+)$','i');for(let i=0;i<lines.length;i++){const m=lines[i].match(re);if(m&&m[1].trim())return m[1].trim().replace(/^['"“”]+|['"“”]+$/g,'');if(new RegExp('^\\s*'+label+'\\s*[:：#\\-]?\\s*$','i').test(lines[i])&&lines[i+1])return lines[i+1].trim()}return ''};
 const style=afterLabel('STYLE'),color=afterLabel('COLOR');
 const quantityRe=/\b(\d+(?:[.,]\d{1,3})?)\s*(kg|kgs|g|grams?|lbs?|ton(?:ne)?s?|m|meters?|metres?|cm|mm|yds?|yards?|pcs?|pieces?|units?|rolls?|boxes|box|sets?)\b/i;
 let q='',u='';for(const line of lines){const m=line.match(quantityRe);if(m){q=m[1].replace(',','.');u=m[2].toUpperCase();break}}
 if(!q){const m=String(text||'').match(/\b(?:QTY|QUANTITY)\s*[:：#\-]?\s*(\d+(?:[.,]\d{1,3})?)/i);if(m)q=m[1].replace(',','.')}
 return {style,color,qty:q,unit:u,raw:String(text||'')};
}
async function processMaterialImages(fileList){
 const files=Array.from(fileList||[]).filter(f=>f&&/^image\//i.test(f.type||''));const status=document.getElementById('scanCameraStatus');
 if(!files.length){status.textContent='No image files selected. Choose one or more image files.';return}
 if(!window.Tesseract){status.textContent='OCR engine could not load. Check internet access and try again.';return}
 whimScanResults=[];renderMaterialScanResults();
 for(let i=0;i<files.length;i++){
  status.textContent=`Reading image ${i+1} of ${files.length}: ${files[i].name||'material label'}…`;
  try{
   const result=await Tesseract.recognize(files[i],'eng',{logger:m=>{if(m.status)status.textContent=`Image ${i+1}/${files.length} — OCR: ${m.status}${m.progress!=null?' '+Math.round(m.progress*100)+'%':''}`}});
   const found=parseMaterialOCR(result.data.text||'');const matched=findScannedMaterial(found.style,found.color);
   whimScanResults.push({...found,fileName:files[i].name||`Image ${i+1}`,code:matched?matched.code:'',matchedCode:matched?matched.code:'',matchedMaterial:matched||null,needsNewCode:!matched});
  }catch(e){whimScanResults.push({fileName:files[i].name||`Image ${i+1}`,style:'',color:'',qty:'',unit:'',raw:'',code:'',matchedCode:'',matchedMaterial:null,needsNewCode:true,error:e.message||'OCR failed'});}
  renderMaterialScanResults();
 }
 status.textContent=`OCR finished for ${files.length} image(s). Review each result; matching style/color pairs use existing item codes automatically.`;
}
function renderMaterialScanResults(){
 const host=document.getElementById('scanResults');if(!host)return;
 host.innerHTML=whimScanResults.map((r,i)=>{
  const match=r.matchedCode?`<p class="scan-match">Existing style and color matched. Existing item code: <b>${esc(r.matchedCode)}</b></p>`:(hasScannedStyle(r.style)?'<p class="scan-new">Existing style, new or unmatched color: enter a new item code.</p>':'<p class="scan-new">New or unmatched style/color: enter a new item code.</p>');
  return `<section class="scan-result"><h3>Image ${i+1}: ${esc(r.fileName)}</h3>${r.error?`<p class="scan-new">OCR error: ${esc(r.error)}</p>`:''}${match}<div class="modal-grid"><div class="field"><label>Item Code</label><input id="scanCode_${i}" value="${esc(r.code)}" ${r.matchedCode?'readonly':''} placeholder="Required for new material" autocomplete="off"></div><div class="field"><label>STYLE</label><input id="scanStyle_${i}" value="${esc(r.style)}"></div><div class="field"><label>COLOR</label><input id="scanColor_${i}" value="${esc(r.color)}"></div><div class="field"><label>Quantity</label><input id="scanQty_${i}" type="number" min="0" step="0.001" value="${esc(r.qty)}"></div><div class="field"><label>Quantity Unit</label><input id="scanUnit_${i}" value="${esc(r.unit)}" placeholder="KG, M, pcs"></div></div><p class="scan-raw">${esc(r.raw||'No text recognized; enter the fields manually.')}</p><button type="button" class="btn" onclick="applyMaterialScanResult(${i})">Use This Material / Inbound Quantity</button></section>`;
 }).join('');
}
function applyMaterialScanResult(i){
 const r=whimScanResults[i];if(!r)return;
 const code=(document.getElementById(`scanCode_${i}`).value||'').trim(),style=(document.getElementById(`scanStyle_${i}`).value||'').trim(),color=(document.getElementById(`scanColor_${i}`).value||'').trim(),qty=(document.getElementById(`scanQty_${i}`).value||'').trim(),unit=(document.getElementById(`scanUnit_${i}`).value||'').trim();
 if(!style||!color){alert('Style and color are required. Verify the OCR fields before applying.');return}
 if(!code){alert('Enter a new item code for this new or unmatched style/color combination.');return}
 if(qty!==''&&(!Number.isFinite(Number(qty))||Number(qty)<0)){alert('Quantity must be a valid non-negative number.');return}
 const exact=findScannedMaterial(style,color);
 if(exact&&normalizeScanValue(exact.code)!==normalizeScanValue(code)){alert(`This style and color already use item code ${exact.code}. The existing code must be used.`);return}
 const mat=state.materials.find(m=>normalizeScanValue(m.code)===normalizeScanValue(code));
 if(mat&&(!exact||normalizeScanValue(mat.code)!==normalizeScanValue(exact.code))){alert('That item code belongs to another material. Choose the matching existing code or enter a new unique code.');return}
 document.getElementById('matCode').value=exact?exact.code:code;
 document.getElementById('matStyle').value=style;document.getElementById('matColor').value=color;
 if(unit)document.getElementById('matUnit').value=unit;
 if(qty!==''){document.getElementById('matTo').value=qty;whimPendingInbound={qty,unit,code:exact?exact.code:code}}
 document.getElementById('materialScannerModal').classList.remove('open');
 alert('Material fields populated. Review and save the Material Information Sheet, then review the inbound movement before saving it. The remaining image results are retained in the scanner.');
}
</script>
'''
s=s[:start]+new+s[end:]
# Rename button to scanner rather than camera icon
s=s.replace('📷 Scan Material Label（扫描物料标签）','▦ Scan Material Labels（扫描物料标签）')
p.write_text(s)
print('patched',len(s))
