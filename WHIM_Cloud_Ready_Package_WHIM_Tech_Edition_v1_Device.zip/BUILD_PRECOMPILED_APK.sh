#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PROJECT="$ROOT/android-apk-project"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java is required. Install JDK 17 or newer." >&2; exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle is not installed. Install Gradle 8.7, or open android-apk-project in Android Studio and build there." >&2; exit 1
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to your Android SDK installation." >&2; exit 1
fi

cd "$PROJECT"
gradle --version
gradle --no-daemon --stacktrace assembleDebug
APK="$PROJECT/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: Gradle finished but expected APK was not found at $APK" >&2; exit 1
fi
mkdir -p "$ROOT/output"
cp "$APK" "$ROOT/output/Warehouse_Inventory_Manager-debug.apk"
echo "APK built: $ROOT/output/Warehouse_Inventory_Manager-debug.apk"
echo "This is a debug APK for testing, not a production release. Test it on Android before distribution."
