Version 1 of Development
========================

WAREHOUSE INVENTORY MANAGER — DUAL PLATFORM PACKAGE
==================================================

Choose the version for the user's device:

WINDOWS PC
- Use winapp/Build_WHIM_EXE.ps1 on Windows to compile WHIM.exe.
- Keep WHIM.exe beside index.html, source.enc and gst-logo.jpg. The executable is a launcher for the existing HTML application, not a self-contained conversion.

ANDROID PHONE/TABLET
- The android-apk-project folder contains an Android Studio project to build an APK.
- Open it in Android Studio and follow android-apk-project/BUILD_ANDROID_APK.txt.
- This ZIP does NOT contain a precompiled APK because Android SDK/Gradle build tools were unavailable here. Do not rename the ZIP to .apk; it will not install.

PRESERVATION
- The existing app HTML, encrypted source, logo, licensing/trial flow,  details, and line-graph application files are carried forward without intentional changes.
- Keep WHIM_Owner_Unlock_Key.json separate. Do not bundle or publish the owner key.
- The Android wrapper is a build scaffold and requires on-device validation before production use.

SETTINGS UPDATE (2026-10-15)
----------------------------
The encrypted application source now includes a heading Settings button, persisted light/dark appearance (light is default), font selection, and import of WHIM-generated Excel (.xlsx) backups. Import validates workbook sheets and asks for confirmation before replacing the current inventory dataset. The import parser also supports deflate-compressed XLSX files on browsers that implement DecompressionStream('deflate-raw').


BROWSER PERSISTENCE AND HEADING BEHAVIOR UPDATE (2026-10-16)
-----------------------------------------------------------
- Clicking outside the heading collapses it and closes the Home menu.
- Scrolling down reveals the heading again.
- The active view is stored and restored after refresh/reopening in the same browser profile.
- Inventory save operations retain localStorage persistence, with additional pagehide/hidden-page save attempts and a warning when storage fails.
- Added a no-JavaScript notice explaining that the user must enable JavaScript in browser settings; web pages cannot override that browser setting.
- Updated encrypted source.enc consistently in Windows and Android project assets.

PERSISTENCE LIMITATIONS
-----------------------
No browser-local application can guarantee 100% persistence: users can clear site data, private browsing may discard it, browser storage can be denied or full, and browser profiles/devices do not share localStorage. Export regular backups and keep them outside browser storage. Cross-browser behavior depends on the browser's JavaScript/Web Crypto support.

HELP ISSUE REPORT UPDATE (2026-10-17)
-----------------------------------
The Help menu now opens a problem-report form. It captures the company name, issue description, and optional reporter email; creates a rule-based troubleshooting tutorial and suggested reply; and opens Gmail compose addressed to mboyanewtonny@gmail.com with the company and issue details plus the tutorial in the report body. The suggested reply is displayed for review/copying. The owner must review and send the Gmail message manually. The offline package does not read the owner inbox or automatically send replies; that requires separately authorized Gmail API access and a backend.

Validation: HTML parser, JavaScript syntax check, source encryption consistency, and ZIP integrity are checked during packaging. Live Gmail, browser interaction, OCR runtime, and APK compilation are not verified here.

WHIM OWNER RESOLUTION RESPONSE UPDATE

The Help issue flow now displays a read-only, owner-style resolution email preview inside the package, addressed in the text to the reporting user when an email is provided. It includes the company, reported problem, tailored troubleshooting/resolution steps, resolution-guidance status, and owner support signature. The preview is generated locally from the problem description and is not an actual message sent by the owner or proof of a verified fix. The separate Gmail issue report still opens as a draft for manual review and sending. Reading the owner inbox or sending a true automatic reply still requires authorized Gmail API integration and a backend.

The multi-image OCR scanner and existing package functionality are retained. The Windows and Android encrypted source assets are synchronized.

Heading/Help cleanup update: explanatory Help interface commentary removed; heading collapses when Help opens and reappears on downward scroll inside Help/report panel. Static validation only; runtime UI and APK build not verified.

WORKSPACE NAVIGATION AND SAFE AUTO-SAVE UPDATE

- Home menu opens by default when the application starts; the last selected workspace remains restored where available.
- Clicking another navigation section collapses ordinary sections. Material Information Sheet and In-Out Warehouse Flow may remain open alongside another section, and can be toggled closed by clicking their own menu button again.
- If the Material Information or Warehouse Movement editor is open when navigation is requested, valid entries are saved first. Missing required fields, missing movement quantities, and invalid/negative numeric values block navigation and are not saved.
- Other open dialogs (including the scanner and Help issue form) block section changes until closed, protecting unsubmitted data.
- Existing explicit Save buttons continue to work. Only complete valid records are committed to persistent inventory state; partial form values are not written to persistent inventory state.

Validation performed: ZIP integrity, HTML parsing, inline JavaScript syntax, and encrypted source synchronization/decryption. Interactive browser testing and Android APK compilation are not claimed.


SETTINGS HUB AND WORKSPACE PERFORMANCE UPDATE (2026-10-17)
---------------------------------------------------------
- Added responsive, icon-led Settings Hub shortcuts for company identity, appearance/Excel import, JSON and Excel backups, email movement summaries, multi-image material scanner, material information, warehouse flow, Help/Support, and refreshing the visible workspace. Shortcuts reuse existing package functions.
- Reduced redundant rendering by refreshing only currently active workspace tables after state changes; inactive workspaces are rendered when opened. This can reduce unnecessary work with larger inventories while keeping views up to date on navigation.
- Added asynchronous/lazy decoding hints to the non-critical company logo preview and reduced-motion support for Settings shortcuts.
- Static checks only; browser runtime performance, OCR behavior, and Android APK compilation require device/browser testing.

WHIM HUB REORGANIZATION UPDATE

The Home button now opens WHIM Hub, which is also the default landing view. The hub uses a centered circular WHIM mark and the WHIM Hub title. Its icon-led menu opens the existing Dashboard, Material Information Sheet, In-Out Warehouse Flow, Backup/Data, scanner, company identity, appearance/import, backup export, movement-summary email, and Help workflows.

Data integrity: no parallel inventory data model or duplicate store was introduced. Existing workflows continue to use the existing shared state, normalization, validation, and local persistence key. The hub's actions invoke existing workflow functions and views. Material and warehouse movement editors retain the existing validation/save-before-navigation behavior. Existing licensing/authentication, scanner/OCR, item-code matching, backup/import/export, owner-resolution preview, and Gmail report handoff remain in the package.

Performance/quality: responsive hub layout, CSS/SVG round WHIM mark (no extra image dependency), reduced-motion-aware tile animation, and existing active-view rendering are retained. The round mark is inline SVG; Windows and Android encrypted source payloads are regenerated from the same HTML bytes.

Validation performed: ZIP integrity, HTML parser, inline JavaScript syntax, duplicate-ID scan, and AES-GCM decrypt/synchrony checks. Full interactive browser/device QA, measured load-time benchmarks, and Android Gradle APK compilation were not performed in this environment.

WHIM HOME TOGGLE AND CENTERED COMPANY IDENTITY UPDATE

The header now has one persistent top-left “⌂ WHIM Home” button. The former separate Settings and Help header buttons were removed because those workflows remain available inside WHIM Hub. The Home button toggles WHIM Hub open and collapsed in sequence, returns to the last Dashboard/Material Information/In-Out Warehouse Flow view when collapsing, and remains visible throughout. The company logo and “GST Garment Manufacturing Company” name are centered in the default app header and hidden while WHIM Hub is open.

The home symbol is the simple house glyph “⌂”, selected for recognizability and compact display on desktop, tablets, and phones. Existing Hub tiles still call the existing workflow functions and shared inventory data path; authentication/licensing, material OCR scanner, inventory, persistence, backup/import/export, movement summaries, and Help/report behavior were not intentionally changed.

Validation performed: ZIP integrity, HTML parse, inline JavaScript syntax, duplicate-ID check, and AES-GCM decrypt/synchrony check between Windows and Android encrypted source assets. Full interactive browser/device testing and Android Gradle APK compilation were not performed.

WHIM HOME MENU UPDATE — 2026-10-18
==================================

- Added two clearly separated top-level menu choices inside WHIM Home: WHIM Hub and Company Identity.
- WHIM Hub uses a grid/workspace icon and navigates to the existing workflow shortcuts.
- Company Identity uses a building icon and navigates to the existing company-name/logo settings.
- Removed Company Identity from the workflow shortcut grid to avoid duplicate menu entries.
- Preserved existing inventory workflows, shared inventory state, backup/data controls, and underlying settings logic.
- Updated the Windows and Android encrypted source payloads together using the existing owner-key/AES-256-GCM format.

Validation performed: ZIP integrity, HTML parse, duplicate-ID scan, inline JavaScript syntax check, source encryption/decryption round-trip, and Windows/Android encrypted payload equality. Full interactive device QA and APK compilation were not performed.

WHIM HOME COLLAPSED MENUS UPDATE

WHIM Home now opens to two menu buttons only: WHIM Hub and Company Identity. Both content panels are collapsed by default. Clicking a menu button opens its corresponding panel; clicking the same button again collapses it, and opening one panel collapses the other. Accessible aria-expanded/aria-controls attributes track the current state.

The existing WHIM Hub workflows, including Dashboard, Material Information Sheet, In-Out Warehouse Flow, scanner/OCR, Backup/Data, exports, email movement summary, and Help/report, remain in the WHIM Hub panel and continue to use the existing shared inventory state. Company Identity is separated into its own collapsible panel. Backup/Data remains inside the WHIM Hub panel so it is not inadvertently hidden with Company Identity. Existing authentication, licensing, persistence, validation, and inventory records were not intentionally changed.

Validation performed: ZIP integrity, HTML parsing, duplicate-ID scan, inline JavaScript syntax, Windows/Android encrypted source byte synchronization, and AES-GCM decrypt equivalence. Full interactive browser/device QA and Android Gradle APK compilation were not performed.

WORKFLOW TOGGLE BEHAVIOR UPDATE
- Material Information Sheet and In-Out Warehouse Flow retain their existing locations and now expose active/collapsed state on their WHIM Hub tiles.
- Each workflow opens on its button click and collapses on a second click of the same button; both can remain open independently to preserve the package's shared-data workflow.
- Validation: archive integrity, HTML parse, duplicate-ID check, inline JS syntax, AES-GCM decrypt verification, and Windows/Android source synchronization. Physical-device testing and APK compilation not performed.

WHIM HOME NESTED MENUS AND PLATFORM RESPONSIVE UPDATE

WHIM Home is the parent menu. Clicking WHIM Home shows the two child menu buttons, WHIM Hub and Company Identity. Both child panels are collapsed by default. Clicking either child button opens its corresponding panel and collapses the other panel; clicking the same active button collapses its panel. Closing WHIM Home resets both child panels to collapsed, and reopening starts with only the two menu buttons visible. Selecting an actual inventory workflow resets child panels and navigates to the existing shared workflow view.

The round WHIM icon and WHIM Hub title remain inside the WHIM Hub panel, not in the default application header. Company Identity remains a separate panel. The existing panel locations and workflow functions are preserved. No duplicate inventory store was added. Existing material and movement data, validation, persistence, authentication/licensing, scanner/OCR, backup/import/export, and owner report handoff are retained.

Platform layout: desktop uses two side-by-side menu buttons with bounded panel width; mobile uses a single-column touch-friendly layout, smaller WHIM mark, safe word wrapping and scroll margins. Reduced-motion preferences remain respected. Windows and Android encrypted source assets are generated from the same HTML bytes using the existing AES-256-GCM owner-key format.

Static verification: ZIP integrity, HTML parsing, JavaScript syntax, duplicate IDs, default hidden panel state, Windows/Android source equality, and AES-GCM decrypt round-trip were checked. Physical device/browser interaction testing, performance benchmarks, and Android Gradle APK compilation were not performed.

WHIM HEADING SCROLL AND WORKFLOW RETURN UPDATE

Heading behavior: scrolling upward hides the sticky heading; scrolling downward reveals it. This is applied to the page and nested vertically scrollable panels, including Help, on desktop, mobile, and tablet layouts. Reduced-motion preference is respected by the CSS transition.

Workflow behavior: clicking the Material Information Sheet menu while it is already open closes that workflow and returns to the WHIM Hub panel. The In-Out Warehouse Flow menu follows the same behavior. Other independently open workflows are not forcibly deleted; all workflows continue to use the same shared state and persistence.

Validation: ZIP integrity, HTML parsing, JavaScript syntax, duplicate IDs, and Windows/Android encrypted-source synchronization/decryption checks performed. Physical-device interaction tests and APK compilation were not performed.

WHIM TRANSPARENT HEADING AND INDEPENDENT SCROLL UPDATE

The heading section background is now fully transparent in light and dark themes. The application uses a bounded, independently scrollable workspace beneath the heading, so editable fields and inventory data do not scroll behind or overlap the heading area. The heading retains its directional hide/show behavior; the workspace scroll is isolated from the page and respects touch scrolling. Existing views, navigation, data persistence, licensing, scanner, backup/import/export, and shared inventory state are retained.

Validation performed: ZIP integrity, HTML structure, duplicate-ID scan, inline JavaScript syntax, AES-GCM decrypt/round-trip, and equality of Windows and Android encrypted source payloads. Full browser/device interaction tests and Android APK compilation were not performed.


WHIM WORKFLOW SAVE/CANCEL UPDATE

Added Save and Close and Cancel actions at the bottom of both the Material Information Sheet and In-Out Warehouse Flow.
- Save and Close validates and saves any open material/movement entry, persists the shared inventory state, and closes the selected workflow back to the WHIM Hub panel. If validation or storage fails, the workflow remains open.
- Cancel closes an in-progress material/movement entry without submitting it, then closes the selected workflow back to WHIM Hub. Inventory changes already committed before cancellation remain saved.
- Both workflows continue using the existing shared inventory state, persistence, and navigation. No APK compilation or physical-device interaction testing was performed.

Validation performed: ZIP integrity, JavaScript syntax, HTML duplicate-ID scan, encrypted source decryption round-trip, and byte equality of Windows/Android encrypted assets.

WHIM HUB-ONLY WORKFLOW ACTION UPDATE

- In-Out Warehouse Flow's Save and Close and Cancel buttons are placed immediately below the “In-Out Warehouse Flow — reference/update ledger” heading.
- Workflow tiles inside WHIM Hub open Material Information Sheet and In-Out Warehouse Flow. Repeated clicks on an already-open workflow tile no longer close the workflow; the explicit Save and Close or Cancel button closes it and returns to WHIM Hub.
- WHIM Home opens the home view and does not toggle back to the previous workflow on repeated clicks. The WHIM Hub child menu controls its own expand/collapse behavior.
- Shared inventory state and existing workflow data paths are preserved.

Validation scope: static source, JavaScript syntax, encrypted asset consistency, and ZIP integrity. No physical-device interaction tests or APK compilation are claimed.


WHIM HEADER LOGO-ALIGNED BRAND UPDATE

- Positioned the compact WHIM Home control at the top-left of the heading, with its icon and label sized together responsively.
- Reserved the top-right header area for the company logo image and company name, arranged side-by-side with responsive sizing for phones, tablets, and desktop screens.
- Made the company identity remain visible when WHIM Hub is open instead of hiding it as part of the Hub-open state.
- Styled the heading with a deep navy-to-blue-to-purple gradient chosen to complement the supplied logo's dark blue and violet palette; the header remains readable in both application themes.
- Preserved the existing scroll-direction behavior: the heading section still hides on upward scroll and reappears on downward scroll. The logo/name remain persistent within the heading state and do not depend on the WHIM Hub open/closed state.
- No inventory schema, workflow, authentication, licensing, or persistence logic was intentionally changed.

Validation performed: ZIP integrity, CSS presence, HTML ID uniqueness, JavaScript syntax, encrypted asset byte parity, and AES-GCM decryption/source-byte parity. Interactive browser/device testing and a new APK compilation were not performed.
